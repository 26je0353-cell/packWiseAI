# PackWise AI

AI-Based Intelligent Food Packaging Material Recommendation System for Food Commodities.
Built for Smart India Hackathon (SIH).

## Architecture

```
packwise-ai/
├── backend/                  FastAPI + SQLite
│   ├── app/
│   │   ├── main.py           API endpoints (recommend, materials, foods, compare)
│   │   ├── database.py       SQLite schema + seeding
│   │   ├── seed_data.py      Prototype foods & materials catalog
│   │   ├── recommendation.py Explainable scoring engine (the "AI")
│   │   └── models.py         Pydantic request/response schemas
│   └── requirements.txt
└── frontend/                 React + Vite + Tailwind
    └── src/
        ├── pages/             Landing, FoodInput, Recommendations, Comparison,
        │                      MaterialExplorer, MaterialDetail, Report
        ├── components/        Header, BottomNav, PageShell, LevelSelector, SegmentedControl
        ├── context/           Global app state (food params, recommendation, compare selection)
        └── api/client.js      Backend API client
```

## How the recommendation engine works

`backend/app/recommendation.py` is a **transparent, rule-based weighted-scoring
model** — not a black-box ML classifier. For each material it computes a
0-100 compatibility score from six "need vs. supply" factors (oxygen,
moisture, light, grease resistance, cost fit, sustainability fit) plus a
packaging-form fit factor (flexible pouch vs rigid container). Every score
comes with a `reasons` list explaining exactly which factors drove it — this
is what "explainable AI" means here, and it's easy to walk judges through the
math live.

All barrier/cost/sustainability values in `seed_data.py` are clearly marked
`data_status: "prototype"` — illustrative demo data, not lab-validated
figures. This is intentional and called out in the UI and report.

## Setup

### 1. Backend (FastAPI)

```bash
cd backend
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

The database (`app/packwise.db`) is created and seeded automatically on
first run. API docs available at http://localhost:8000/docs

### 2. Frontend (React + Vite)

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

By default the frontend calls the backend at `http://localhost:8000`. To
change this, create `frontend/.env` with:

```
VITE_API_BASE_URL=http://localhost:8000
```

## User flow

Landing → Select Food & set parameters (Food Input) → Analyze → 3 ranked
AI recommendations → select any/all 3 → Compare side-by-side → open full
Material Explorer / Material Detail → Generate & print Report.

## API endpoints

| Method | Endpoint                    | Description                              |
|--------|------------------------------|-------------------------------------------|
| GET    | `/foods`                    | List all seeded food commodities          |
| GET    | `/materials`                | List all packaging materials + properties |
| GET    | `/materials/{id}`           | Single material detail                    |
| POST   | `/recommend`                | Run the engine, get top-3 ranked results  |
| GET    | `/recommend/{id}`           | Retrieve a past recommendation run        |
| POST   | `/compare`                  | Full detail for 2-3 selected material IDs |

## Notes for judges / demo

- The scoring logic and its weights are declared as plain constants at the
  top of `recommendation.py` — nothing hidden, easy to explain live.
- No unsupported "99% accuracy" style claims are made anywhere in the UI.
- Every recommendation is logged to the `recommendations` table so a report
  can always be regenerated from its ID.
