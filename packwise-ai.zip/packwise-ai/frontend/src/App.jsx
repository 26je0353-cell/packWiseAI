import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Landing from './pages/Landing.jsx'
import FoodInput from './pages/FoodInput.jsx'
import Recommendations from './pages/Recommendations.jsx'
import Comparison from './pages/Comparison.jsx'
import MaterialExplorer from './pages/MaterialExplorer.jsx'
import MaterialDetail from './pages/MaterialDetail.jsx'
import Report from './pages/Report.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/food-input" element={<FoodInput />} />
      <Route path="/recommendations" element={<Recommendations />} />
      <Route path="/comparison" element={<Comparison />} />
      <Route path="/materials" element={<MaterialExplorer />} />
      <Route path="/materials/:id" element={<MaterialDetail />} />
      <Route path="/report" element={<Report />} />
    </Routes>
  )
}
