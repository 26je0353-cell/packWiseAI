const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

async function handle(res) {
  if (!res.ok) {
    let detail = res.statusText
    try {
      const body = await res.json()
      detail = body.detail || detail
    } catch (_) {
      /* ignore */
    }
    throw new Error(detail)
  }
  return res.json()
}

export const api = {
  getFoods: () => fetch(`${BASE_URL}/foods`).then(handle),
  getMaterials: () => fetch(`${BASE_URL}/materials`).then(handle),
  getMaterial: (id) => fetch(`${BASE_URL}/materials/${id}`).then(handle),
  recommend: (payload) =>
    fetch(`${BASE_URL}/recommend`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).then(handle),
  getRecommendation: (id) => fetch(`${BASE_URL}/recommend/${id}`).then(handle),
  compare: (materialIds) =>
    fetch(`${BASE_URL}/compare`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ material_ids: materialIds }),
    }).then(handle),
}
