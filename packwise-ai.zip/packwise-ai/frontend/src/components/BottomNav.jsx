import React from 'react'
import { NavLink } from 'react-router-dom'

const TABS = [
  { path: '/', icon: 'dashboard', label: 'Home' },
  { path: '/food-input', icon: 'science', label: 'Analysis' },
  { path: '/recommendations', icon: 'verified', label: 'Results' },
  { path: '/comparison', icon: 'compare_arrows', label: 'Compare' },
  { path: '/materials', icon: 'inventory_2', label: 'Materials' },
]

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 w-full z-50 pb-safe bg-surface-container-lowest/90 backdrop-blur-xl shadow-[0_-2px_12px_rgba(19,27,46,0.05)]">
      <div className="flex items-center justify-around h-16 px-1">
        {TABS.map((tab) => (
          <NavLink
            key={tab.path}
            to={tab.path}
            end={tab.path === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center w-14 h-12 rounded-lg transition-colors ${
                isActive
                  ? 'text-primary-container font-semibold bg-surface-container/60'
                  : 'text-on-surface-variant'
              }`
            }
          >
            <span className="material-symbols-outlined text-[22px]">{tab.icon}</span>
            <span className="font-label-caps text-[10px] mt-0.5">{tab.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
