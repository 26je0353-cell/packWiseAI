import React from 'react'

const LEVEL_LABELS = ['Low', 'Mild', 'Med', 'High', 'Critical']

export default function LevelSelector({ icon, title, description, value, onChange, unitHint }) {
  const tier = LEVEL_LABELS[value - 1] || 'Med'
  const isCritical = value === 5
  const isHigh = value === 4

  return (
    <div className="rounded-lg bg-surface-container-low p-space-sm flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          {icon && <span className="material-symbols-outlined text-[16px] text-secondary">{icon}</span>}
          <span className="font-body-md text-body-md font-semibold text-on-surface">{title}</span>
        </div>
        <span
          className={`font-label-caps text-[10px] px-2 py-0.5 rounded-full font-bold ${
            isCritical
              ? 'bg-error-container text-on-error-container'
              : isHigh
              ? 'bg-secondary-container text-on-secondary-container'
              : 'bg-surface-container text-on-surface-variant'
          }`}
        >
          {tier.toUpperCase()}
        </span>
      </div>
      {description && <p className="font-body-sm text-body-sm text-on-surface-variant">{description}</p>}
      <div className="grid grid-cols-5 gap-1 pt-1">
        {LEVEL_LABELS.map((label, i) => {
          const level = i + 1
          const active = level === value
          return (
            <button
              key={label}
              type="button"
              onClick={() => onChange(level)}
              className={`text-center py-1 rounded font-label-caps text-[10px] transition-colors flex items-center justify-center gap-0.5 ${
                active
                  ? level === 5
                    ? 'bg-error text-on-error font-bold shadow-sm'
                    : 'bg-primary-container text-on-primary font-bold shadow-sm'
                  : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
              }`}
            >
              {active && <span className="material-symbols-outlined text-[12px]">check</span>}
              {label}
            </button>
          )
        })}
      </div>
      {unitHint && (
        <div className="flex items-center justify-between pt-1 font-technical-data text-[11px] text-on-surface-variant">
          <span>{unitHint.label}</span>
          <span className="font-semibold text-primary">{unitHint.value}</span>
        </div>
      )}
    </div>
  )
}
