import React from 'react'
import Header from './Header.jsx'
import BottomNav from './BottomNav.jsx'

export default function PageShell({ subtitle, children }) {
  return (
    <div className="bg-background text-on-surface antialiased flex flex-col min-h-screen">
      <Header subtitle={subtitle} />
      <main className="flex-1 flex flex-col relative w-full pt-16 pb-20 bg-background">
        <div className="flex flex-col w-full px-gutter-mobile py-space-md gap-space-md max-w-2xl mx-auto">
          {children}
        </div>
      </main>
      <BottomNav />
    </div>
  )
}
