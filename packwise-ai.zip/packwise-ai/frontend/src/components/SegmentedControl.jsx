import React from 'react'

export default function SegmentedControl({ options, value, onChange, columns = 3 }) {
  return (
    <div
      className="grid gap-1 p-1 bg-surface-container-low rounded-lg"
      style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}
    >
      {options.map((opt) => {
        const active = opt.value === value
        return (
          <button
            key={opt.label}
            type="button"
            onClick={() => onChange(opt.value)}
            className={`py-1.5 rounded font-label-caps text-[10.5px] text-center leading-tight transition-colors ${
              active
                ? 'font-semibold bg-primary-container text-on-primary shadow-sm'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            {opt.label}
          </button>
        )
      })}
    </div>
  )
}
