import React, { createContext, useContext, useState, useCallback } from 'react'

const AppContext = createContext(null)

const DEFAULT_PARAMS = {
  food_id: null,
  food_name: 'Potato Chips / Savory Crisps',
  food_category: 'Snacks & Confectionery',
  moisture_sensitivity: 5,
  oxygen_sensitivity: 4,
  light_sensitivity: 4,
  fat_content: 5,
  storage_temperature_c: 25,
  relative_humidity: 75,
  expected_shelf_life_days: 270,
  cost_priority: 3,
  sustainability_priority: 3,
}

export function AppProvider({ children }) {
  const [foodParams, setFoodParams] = useState(DEFAULT_PARAMS)
  const [recommendation, setRecommendation] = useState(null) // { recommendation_id, food_name, results }
  const [selectedForCompare, setSelectedForCompare] = useState([]) // array of material_ids (max 3)

  const updateFoodParams = useCallback((patch) => {
    setFoodParams((prev) => ({ ...prev, ...patch }))
  }, [])

  const toggleCompareSelection = useCallback((materialId) => {
    setSelectedForCompare((prev) => {
      if (prev.includes(materialId)) return prev.filter((id) => id !== materialId)
      if (prev.length >= 3) return prev
      return [...prev, materialId]
    })
  }, [])

  const value = {
    foodParams,
    updateFoodParams,
    setFoodParams,
    recommendation,
    setRecommendation,
    selectedForCompare,
    setSelectedForCompare,
    toggleCompareSelection,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useAppContext() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useAppContext must be used within AppProvider')
  return ctx
}
