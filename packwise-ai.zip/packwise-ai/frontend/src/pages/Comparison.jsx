import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'
import { useAppContext } from '../context/AppContext.jsx'
import { api } from '../api/client.js'

const ROWS = [
  { key: 'oxygen_barrier', label: 'Oxygen Barrier', scale: true },
  { key: 'moisture_barrier', label: 'Moisture Barrier', scale: true },
  { key: 'light_barrier', label: 'Light Barrier', scale: true },
  { key: 'grease_resistance', label: 'Grease Resistance', scale: true },
  { key: 'mechanical_strength', label: 'Mechanical Strength', scale: true },
  { key: 'heat_resistance', label: 'Heat Resistance', scale: true },
  { key: 'cost_level', label: 'Cost Level', scale: true, invert: true },
  { key: 'sustainability_level', label: 'Sustainability', scale: true },
]

function ScaleDots({ value, invert }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          className={`w-2 h-2 rounded-full ${
            i <= value ? (invert ? 'bg-amber-600' : 'bg-primary-container') : 'bg-surface-container-high'
          }`}
        />
      ))}
    </div>
  )
}

export default function Comparison() {
  const navigate = useNavigate()
  const { selectedForCompare, toggleCompareSelection, recommendation } = useAppContext()
  const [materials, setMaterials] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (selectedForCompare.length < 2) return
    setLoading(true)
    api
      .compare(selectedForCompare)
      .then((res) => setMaterials(res.materials))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [selectedForCompare])

  if (selectedForCompare.length < 2) {
    return (
      <PageShell subtitle="Material Comparison">
        <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
          <span className="material-symbols-outlined text-[40px] text-on-surface-variant">compare_arrows</span>
          <p className="font-body-md text-body-md text-on-surface-variant">
            Select 2 or 3 materials from your recommendations to compare them side-by-side.
          </p>
          <button
            onClick={() => navigate('/recommendations')}
            className="mt-2 px-4 py-2.5 rounded-xl bg-primary-container text-on-primary font-body-md font-semibold"
          >
            Go to Recommendations
          </button>
        </div>
      </PageShell>
    )
  }

  return (
    <PageShell subtitle="Material Comparison">
      <div className="rounded-xl bg-surface-container-low p-space-md shadow-sm">
        <div className="flex items-center gap-1.5 text-secondary">
          <span className="material-symbols-outlined text-[18px]">compare_arrows</span>
          <span className="font-label-caps text-label-caps uppercase tracking-wider font-semibold">
            Side-by-Side Comparison
          </span>
        </div>
        <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
          Comparing {selectedForCompare.length} materials
          {recommendation ? ` for ${recommendation.food_name}` : ''}.
        </p>
      </div>

      {loading && <p className="font-body-sm text-on-surface-variant text-center py-4">Loading comparison...</p>}
      {error && (
        <div className="rounded-lg bg-error-container p-space-sm text-on-error-container font-body-sm text-body-sm">
          {error}
        </div>
      )}

      {!loading && materials.length > 0 && (
        <div className="overflow-x-auto rounded-xl bg-surface-container-lowest shadow-sm no-scrollbar">
          <table className="min-w-full text-left border-collapse">
            <thead>
              <tr>
                <th className="p-space-sm font-label-caps text-[10px] text-on-surface-variant uppercase sticky left-0 bg-surface-container-lowest">
                  Property
                </th>
                {materials.map((m) => (
                  <th key={m.id} className="p-space-sm min-w-[140px]">
                    <div className="flex flex-col gap-1">
                      <span className="font-body-sm text-body-sm font-bold text-on-surface leading-tight">
                        {m.name}
                      </span>
                      <button
                        onClick={() => toggleCompareSelection(m.id)}
                        className="self-start font-label-caps text-[9px] text-error flex items-center gap-0.5"
                      >
                        <span className="material-symbols-outlined text-[12px]">close</span>
                        Remove
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ROWS.map((row, i) => (
                <tr key={row.key} className={i % 2 === 0 ? 'bg-surface-container-low/40' : ''}>
                  <td className="p-space-sm font-body-sm text-body-sm font-medium text-on-surface sticky left-0 bg-inherit">
                    {row.label}
                  </td>
                  {materials.map((m) => (
                    <td key={m.id} className="p-space-sm">
                      <ScaleDots value={m[row.key]} invert={row.invert} />
                    </td>
                  ))}
                </tr>
              ))}
              <tr className="bg-surface-container-low/40">
                <td className="p-space-sm font-body-sm text-body-sm font-medium text-on-surface sticky left-0 bg-inherit">
                  Recyclable / Compostable
                </td>
                {materials.map((m) => (
                  <td key={m.id} className="p-space-sm font-body-sm text-[12px] text-on-surface-variant">
                    {m.recyclable ? 'Recyclable' : ''}
                    {m.recyclable && m.compostable ? ' · ' : ''}
                    {m.compostable ? 'Compostable' : ''}
                    {!m.recyclable && !m.compostable ? '—' : ''}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="p-space-sm font-body-sm text-body-sm font-medium text-on-surface sticky left-0 bg-inherit align-top">
                  Applications
                </td>
                {materials.map((m) => (
                  <td key={m.id} className="p-space-sm font-body-sm text-[12px] text-on-surface-variant align-top">
                    {m.example_applications}
                  </td>
                ))}
              </tr>
              <tr className="bg-surface-container-low/40">
                <td className="p-space-sm font-body-sm text-body-sm font-medium text-on-surface sticky left-0 bg-inherit align-top">
                  Advantages
                </td>
                {materials.map((m) => (
                  <td key={m.id} className="p-space-sm align-top">
                    <ul className="flex flex-col gap-1">
                      {m.advantages.map((a, idx) => (
                        <li key={idx} className="font-body-sm text-[11.5px] text-on-surface-variant flex gap-1">
                          <span className="material-symbols-outlined text-[12px] text-primary flex-shrink-0 mt-0.5">
                            check
                          </span>
                          {a}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="p-space-sm font-body-sm text-body-sm font-medium text-on-surface sticky left-0 bg-inherit align-top">
                  Limitations
                </td>
                {materials.map((m) => (
                  <td key={m.id} className="p-space-sm align-top">
                    <ul className="flex flex-col gap-1">
                      {m.limitations.map((l, idx) => (
                        <li key={idx} className="font-body-sm text-[11.5px] text-on-surface-variant flex gap-1">
                          <span className="material-symbols-outlined text-[12px] text-error flex-shrink-0 mt-0.5">
                            priority_high
                          </span>
                          {l}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>
              <tr className="bg-surface-container-low/40">
                <td className="p-space-sm font-body-sm text-body-sm font-medium text-on-surface sticky left-0 bg-inherit">
                  Data Status
                </td>
                {materials.map((m) => (
                  <td key={m.id} className="p-space-sm">
                    <span
                      className={`font-label-caps text-[9px] px-2 py-0.5 rounded-full ${
                        m.data_status === 'validated'
                          ? 'bg-primary-container text-on-primary'
                          : 'bg-surface-container text-on-surface-variant'
                      }`}
                    >
                      {m.data_status === 'validated' ? 'Validated' : 'Prototype/Demo'}
                    </span>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      )}

      <button
        onClick={() => navigate('/report')}
        className="w-full py-3 px-space-md rounded-xl bg-primary-container text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md active:scale-[0.99]"
      >
        <span className="material-symbols-outlined text-[20px]">description</span>
        Generate Report
      </button>
    </PageShell>
  )
}
