import React, { useEffect, useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'
import LevelSelector from '../components/LevelSelector.jsx'
import SegmentedControl from '../components/SegmentedControl.jsx'
import { useAppContext } from '../context/AppContext.jsx'
import { api } from '../api/client.js'

const CATEGORIES = [
  'Snacks & Confectionery',
  'Dairy & Meats',
  'Fresh Produce',
  'Beverages',
  'Bakery & Cereals',
  'Sauces & Condiments',
]

const COST_OPTIONS = [
  { label: 'Economy ($)', value: 5 },
  { label: 'Balanced ($$)', value: 3 },
  { label: 'Premium ($$$)', value: 1 },
]

const SUSTAINABILITY_OPTIONS = [
  { label: 'Standard Recyclable', value: 2 },
  { label: 'High PCR / Bio-based', value: 4 },
  { label: '100% Compostable', value: 5 },
]

function tempTier(temp) {
  if (temp <= 10) return { label: 'Cold Storage', cls: 'bg-tertiary-container/20 text-on-tertiary-fixed-variant' }
  if (temp <= 22) return { label: 'Cellar / Cool', cls: 'bg-surface-container text-on-surface-variant' }
  if (temp <= 30) return { label: 'Ambient Retail', cls: 'bg-surface-container text-on-surface-variant' }
  return { label: 'Tropical Stress', cls: 'bg-error-container text-on-error-container font-semibold' }
}

function rhTier(rh) {
  if (rh <= 35) return { label: 'Arid / Dry Safe', cls: 'bg-primary/10 text-primary font-bold' }
  if (rh <= 65) return { label: 'Standard Shelf', cls: 'bg-secondary-container/50 text-on-secondary-container font-medium' }
  if (rh <= 80) return { label: 'Monsoon Tested', cls: 'bg-amber-500/15 text-amber-700 font-semibold' }
  return { label: 'Extreme Moisture', cls: 'bg-error-container text-on-error-container font-bold' }
}

export default function FoodInput() {
  const navigate = useNavigate()
  const { foodParams, updateFoodParams, setRecommendation } = useAppContext()
  const [foods, setFoods] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [foodQuery, setFoodQuery] = useState(foodParams.food_name)

  useEffect(() => {
    api.getFoods().then(setFoods).catch(() => setFoods([]))
  }, [])

  const filteredFoods = useMemo(() => {
    if (!foodQuery) return foods
    return foods.filter((f) => f.name.toLowerCase().includes(foodQuery.toLowerCase()))
  }, [foods, foodQuery])

  const handleSelectFood = (food) => {
    setFoodQuery(food.name)
    updateFoodParams({
      food_id: food.id,
      food_name: food.name,
      food_category: food.category,
      moisture_sensitivity: food.default_moisture_sensitivity,
      oxygen_sensitivity: food.default_oxygen_sensitivity,
      light_sensitivity: food.default_light_sensitivity,
      fat_content: food.default_fat_content,
    })
  }

  const shelfMonths = Math.round(foodParams.expected_shelf_life_days / 30)
  const tTier = tempTier(foodParams.storage_temperature_c)
  const rTier = rhTier(foodParams.relative_humidity)

  const handleAnalyze = async () => {
    setLoading(true)
    setError(null)
    try {
      const payload = { ...foodParams, food_name: foodQuery || foodParams.food_name }
      const result = await api.recommend(payload)
      setRecommendation(result)
      navigate('/recommendations')
    } catch (e) {
      setError(e.message || 'Failed to get recommendations. Is the backend running?')
    } finally {
      setLoading(false)
    }
  }

  return (
    <PageShell subtitle="Food Input">
      <div className="relative overflow-hidden rounded-xl bg-surface-container-low p-space-md shadow-sm">
        <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-secondary/10 blur-2xl pointer-events-none" />
        <div className="relative flex flex-col gap-1 z-10">
          <div className="flex items-center gap-1.5 text-secondary">
            <span className="material-symbols-outlined text-[18px]">biotech</span>
            <span className="font-label-caps text-label-caps uppercase tracking-wider font-semibold">
              Laboratory Calibration Console
            </span>
          </div>
          <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-primary tracking-tight">
            Food Degradation & Parameter Studio
          </h1>
          <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
            Configure commodity characteristics and storage constraints to generate AI-matched
            packaging formulations.
          </p>
        </div>
      </div>

      {/* SECTION 1: Commodity Selection */}
      <div className="flex flex-col rounded-xl bg-surface-container-lowest p-space-md shadow-sm gap-space-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
            <span className="material-symbols-outlined text-[16px]">fastfood</span>
          </div>
          <span className="font-headline-sm text-headline-sm text-on-surface">1. Commodity Spec</span>
        </div>

        <div className="relative rounded-lg bg-surface-container-low p-space-sm flex flex-col gap-2">
          <div className="flex items-center gap-2 bg-surface-container-lowest rounded-lg px-3 py-2 shadow-sm">
            <span className="material-symbols-outlined text-secondary text-[20px]">search</span>
            <input
              className="font-body-md text-body-md text-on-surface bg-transparent w-full focus:outline-none font-medium"
              value={foodQuery}
              onChange={(e) => setFoodQuery(e.target.value)}
              placeholder="Search food commodity..."
            />
          </div>
          {foodQuery && filteredFoods.length > 0 && (
            <div className="flex flex-col gap-1 max-h-40 overflow-y-auto">
              {filteredFoods.slice(0, 6).map((f) => (
                <button
                  key={f.id}
                  onClick={() => handleSelectFood(f)}
                  className="text-left px-3 py-2 rounded-lg bg-surface-container-lowest hover:bg-surface-container-high transition-colors font-body-sm text-body-sm text-on-surface"
                >
                  {f.name}
                  <span className="text-on-surface-variant"> — {f.category}</span>
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center gap-2 px-1">
            <span className="font-label-caps text-label-caps px-2 py-0.5 rounded bg-tertiary-container/20 text-on-tertiary-fixed-variant">
              {foodParams.food_category}
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-1.5 pt-1">
          <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
            Category Archetype
          </span>
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar -mx-1 px-1">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => updateFoodParams({ food_category: cat })}
                className={`whitespace-nowrap px-3 py-1.5 rounded-full font-label-caps text-label-caps transition-colors ${
                  foodParams.food_category === cat
                    ? 'bg-primary-container text-on-primary shadow-sm'
                    : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* SECTION 2: Spoilage Sensitivity Controls */}
      <div className="flex flex-col rounded-xl bg-surface-container-lowest p-space-md shadow-sm gap-space-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-secondary/10 flex items-center justify-center text-secondary">
            <span className="material-symbols-outlined text-[16px]">crisis_alert</span>
          </div>
          <span className="font-headline-sm text-headline-sm text-on-surface">2. Spoilage Kinetics</span>
        </div>

        <LevelSelector
          icon="water_drop"
          title="Moisture Sensitivity"
          description="Loss of crispness & staling risk under humid storage"
          value={foodParams.moisture_sensitivity}
          onChange={(v) => updateFoodParams({ moisture_sensitivity: v })}
        />
        <LevelSelector
          icon="air"
          title="Oxygen Sensitivity"
          description="Lipid oxidation & rancidity hazard"
          value={foodParams.oxygen_sensitivity}
          onChange={(v) => updateFoodParams({ oxygen_sensitivity: v })}
        />
        <LevelSelector
          icon="wb_sunny"
          title="Light / UV Sensitivity"
          description="Photo-oxidation of pigments, flavor & nutrients"
          value={foodParams.light_sensitivity}
          onChange={(v) => updateFoodParams({ light_sensitivity: v })}
        />
        <LevelSelector
          icon="opacity"
          title="Fat / Lipid Content"
          description="Higher fat needs stronger grease-resistant inner ply"
          value={foodParams.fat_content}
          onChange={(v) => updateFoodParams({ fat_content: v })}
        />
      </div>

      {/* SECTION 3: Ambient & Distribution Conditions */}
      <div className="flex flex-col rounded-xl bg-surface-container-lowest p-space-md shadow-sm gap-space-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary-container/10 flex items-center justify-center text-primary-container">
            <span className="material-symbols-outlined text-[16px]">thermostat</span>
          </div>
          <span className="font-headline-sm text-headline-sm text-on-surface">3. Ambient Exposure Profile</span>
        </div>

        <div className="flex flex-col gap-1.5 pt-1">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1.5">
              <span className="font-body-md text-body-md text-on-surface font-semibold">Storage Temperature</span>
              <span className={`font-label-caps text-[10px] px-2 py-0.5 rounded ${tTier.cls}`}>{tTier.label}</span>
            </div>
            <span className="font-metric-display text-[17px] text-primary font-bold px-2 py-0.5 rounded bg-primary/10 border border-primary/20">
              {foodParams.storage_temperature_c}°C
            </span>
          </div>
          <input
            type="range"
            min={5}
            max={45}
            step={1}
            value={foodParams.storage_temperature_c}
            onChange={(e) => updateFoodParams({ storage_temperature_c: Number(e.target.value) })}
            className="w-full h-2 rounded-lg cursor-pointer"
            style={{
              background: `linear-gradient(to right, #0f5132 0%, #0f5132 ${
                ((foodParams.storage_temperature_c - 5) / 40) * 100
              }%, #dae2fd ${((foodParams.storage_temperature_c - 5) / 40) * 100}%, #dae2fd 100%)`,
            }}
          />
        </div>

        <div className="flex flex-col gap-1.5 pt-2">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1.5">
              <span className="font-body-md text-body-md text-on-surface font-semibold">Relative Humidity (RH)</span>
              <span className={`font-label-caps text-[10px] px-2 py-0.5 rounded-full ${rTier.cls}`}>{rTier.label}</span>
            </div>
            <span className="font-metric-display text-[17px] text-secondary font-bold px-2 py-0.5 rounded bg-secondary/10 border border-secondary/20">
              {foodParams.relative_humidity}% RH
            </span>
          </div>
          <input
            type="range"
            min={10}
            max={98}
            step={1}
            value={foodParams.relative_humidity}
            onChange={(e) => updateFoodParams({ relative_humidity: Number(e.target.value) })}
            className="w-full h-2 rounded-lg cursor-pointer"
            style={{
              background: `linear-gradient(to right, #006a61 0%, #006a61 ${
                ((foodParams.relative_humidity - 10) / 88) * 100
              }%, #dae2fd ${((foodParams.relative_humidity - 10) / 88) * 100}%, #dae2fd 100%)`,
            }}
          />
        </div>

        <div className="flex items-center justify-between pt-1 rounded-lg bg-surface-container-low p-space-sm">
          <div className="flex flex-col">
            <span className="font-body-md text-body-md font-semibold text-on-surface">
              Expected Shelf Life Target
            </span>
            <span className="font-technical-data text-[11px] text-on-surface-variant">
              Nominal target cutoff
            </span>
          </div>
          <div className="flex items-center gap-2 bg-surface-container-lowest rounded-lg p-1 shadow-sm border border-outline-variant/30">
            <button
              onClick={() =>
                updateFoodParams({
                  expected_shelf_life_days: Math.max(7, foodParams.expected_shelf_life_days - 30),
                })
              }
              className="w-7 h-7 rounded flex items-center justify-center text-on-surface hover:bg-surface-container active:scale-95 transition-all"
            >
              <span className="material-symbols-outlined text-[16px]">remove</span>
            </button>
            <span className="font-technical-data text-[12px] font-bold text-primary px-1">
              {shelfMonths} Mos ({foodParams.expected_shelf_life_days}d)
            </span>
            <button
              onClick={() =>
                updateFoodParams({
                  expected_shelf_life_days: Math.min(730, foodParams.expected_shelf_life_days + 30),
                })
              }
              className="w-7 h-7 rounded flex items-center justify-center text-on-surface hover:bg-surface-container active:scale-95 transition-all"
            >
              <span className="material-symbols-outlined text-[16px]">add</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 4: Optimization Priorities */}
      <div className="flex flex-col rounded-xl bg-surface-container-lowest p-space-md shadow-sm gap-space-sm">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-tertiary-container/10 flex items-center justify-center text-tertiary-container">
            <span className="material-symbols-outlined text-[16px]">tune</span>
          </div>
          <span className="font-headline-sm text-headline-sm text-on-surface">4. Optimization Priorities</span>
        </div>

        <div className="flex flex-col gap-1.5">
          <span className="font-body-md text-body-md text-on-surface font-medium">Cost Sensitivity</span>
          <SegmentedControl
            options={COST_OPTIONS}
            value={foodParams.cost_priority}
            onChange={(v) => updateFoodParams({ cost_priority: v })}
          />
        </div>

        <div className="flex flex-col gap-1.5 pt-1">
          <span className="font-body-md text-body-md text-on-surface font-medium">Sustainability Tier</span>
          <SegmentedControl
            options={SUSTAINABILITY_OPTIONS}
            value={foodParams.sustainability_priority}
            onChange={(v) => updateFoodParams({ sustainability_priority: v })}
          />
        </div>
      </div>

      {error && (
        <div className="rounded-lg bg-error-container p-space-sm text-on-error-container font-body-sm text-body-sm">
          {error}
        </div>
      )}

      <button
        onClick={handleAnalyze}
        disabled={loading}
        className="relative group overflow-hidden w-full py-3.5 px-space-md rounded-xl bg-primary-container text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all active:scale-[0.99] disabled:opacity-60"
      >
        <span className={`material-symbols-outlined text-[20px] ${loading ? 'animate-spin' : ''}`}>
          {loading ? 'progress_activity' : 'auto_awesome'}
        </span>
        <span className="tracking-wide font-bold">{loading ? 'Analyzing...' : 'Analyze Packaging'}</span>
        {!loading && (
          <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
            arrow_forward
          </span>
        )}
      </button>
    </PageShell>
  )
}
