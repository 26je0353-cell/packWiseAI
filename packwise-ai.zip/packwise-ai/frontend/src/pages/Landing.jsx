import React from 'react'
import { useNavigate } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'

const STEPS = [
  { icon: 'fastfood', title: 'Select Food', desc: 'Choose a commodity & category' },
  { icon: 'science', title: 'Set Parameters', desc: 'Sensitivities & storage conditions' },
  { icon: 'auto_awesome', title: 'AI Analysis', desc: 'Explainable compatibility scoring' },
  { icon: 'verified', title: '3 Recommendations', desc: 'Ranked, transparent results' },
  { icon: 'compare_arrows', title: 'Compare & Report', desc: 'Side-by-side, export summary' },
]

export default function Landing() {
  const navigate = useNavigate()

  return (
    <PageShell subtitle="AI Packaging Advisor">
      <div className="relative overflow-hidden rounded-xl bg-surface-container-low p-space-md shadow-sm">
        <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-secondary/10 blur-2xl pointer-events-none" />
        <div className="relative flex flex-col gap-1 z-10">
          <div className="flex items-center gap-1.5 text-secondary">
            <span className="material-symbols-outlined text-[18px]">biotech</span>
            <span className="font-label-caps text-label-caps uppercase tracking-wider font-semibold">
              SIH Prototype
            </span>
          </div>
          <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-primary tracking-tight">
            AI-Based Intelligent Food Packaging Material Recommendation
          </h1>
          <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
            Enter your food commodity and storage conditions to get 3 ranked, fully explainable
            packaging material recommendations — with transparent reasoning, not black-box claims.
          </p>
        </div>
      </div>

      <div className="flex flex-col rounded-xl bg-surface-container-lowest p-space-md shadow-sm gap-space-sm">
        <span className="font-headline-sm text-headline-sm text-on-surface">How it works</span>
        <div className="flex flex-col gap-2">
          {STEPS.map((s, i) => (
            <div key={s.title} className="flex items-center gap-3 rounded-lg bg-surface-container-low p-space-sm">
              <div className="w-9 h-9 rounded-full bg-primary-container/15 flex items-center justify-center text-primary flex-shrink-0">
                <span className="material-symbols-outlined text-[18px]">{s.icon}</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-body-md text-body-md font-semibold text-on-surface">
                  {i + 1}. {s.title}
                </span>
                <span className="font-body-sm text-body-sm text-on-surface-variant">{s.desc}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-lg bg-secondary-container/20 p-space-sm flex items-start gap-2">
        <span className="material-symbols-outlined text-[18px] text-secondary flex-shrink-0 mt-0.5">
          info
        </span>
        <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
          Barrier and sustainability figures in this prototype are illustrative demo values, not
          experimentally validated lab data. See each material's data status tag for details.
        </p>
      </div>

      <button
        onClick={() => navigate('/food-input')}
        className="relative group overflow-hidden w-full py-3.5 px-space-md rounded-xl bg-primary-container text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all active:scale-[0.99]"
      >
        <span className="material-symbols-outlined text-[20px]">fastfood</span>
        <span className="tracking-wide font-bold">Start: Select Food</span>
        <span className="material-symbols-outlined text-[20px] group-hover:translate-x-1 transition-transform">
          arrow_forward
        </span>
      </button>
    </PageShell>
  )
}
