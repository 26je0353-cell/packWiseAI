import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'
import { api } from '../api/client.js'
import { useAppContext } from '../context/AppContext.jsx'

const PROPS = [
  { key: 'oxygen_barrier', label: 'Oxygen Barrier', icon: 'air' },
  { key: 'moisture_barrier', label: 'Moisture Barrier', icon: 'water_drop' },
  { key: 'light_barrier', label: 'Light Barrier', icon: 'wb_sunny' },
  { key: 'grease_resistance', label: 'Grease Resistance', icon: 'opacity' },
  { key: 'mechanical_strength', label: 'Mechanical Strength', icon: 'fitness_center' },
  { key: 'heat_resistance', label: 'Heat Resistance', icon: 'local_fire_department' },
  { key: 'sustainability_level', label: 'Sustainability', icon: 'eco' },
]

export default function MaterialDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { toggleCompareSelection, selectedForCompare } = useAppContext()
  const [material, setMaterial] = useState(null)
  const [error, setError] = useState(null)

  useEffect(() => {
    api
      .getMaterial(id)
      .then(setMaterial)
      .catch((e) => setError(e.message))
  }, [id])

  if (error) {
    return (
      <PageShell subtitle="Material Detail">
        <div className="rounded-lg bg-error-container p-space-sm text-on-error-container font-body-sm text-body-sm">
          {error}
        </div>
      </PageShell>
    )
  }

  if (!material) {
    return (
      <PageShell subtitle="Material Detail">
        <p className="font-body-sm text-on-surface-variant text-center py-6">Loading...</p>
      </PageShell>
    )
  }

  const isSelected = selectedForCompare.includes(material.id)

  return (
    <PageShell subtitle="Material Detail">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1 self-start text-on-surface-variant font-body-sm text-body-sm"
      >
        <span className="material-symbols-outlined text-[18px]">arrow_back</span>
        Back
      </button>

      <div className="rounded-xl bg-surface-container-low p-space-md shadow-sm">
        <div className="flex items-center justify-between">
          <span className="font-label-caps text-[10px] px-2 py-0.5 rounded bg-secondary-container/40 text-on-secondary-container font-semibold">
            {material.short_code}
          </span>
          <span
            className={`font-label-caps text-[9px] px-2 py-0.5 rounded-full ${
              material.data_status === 'validated'
                ? 'bg-primary-container text-on-primary'
                : 'bg-surface-container text-on-surface-variant'
            }`}
          >
            {material.data_status === 'validated' ? 'Validated' : 'Prototype/Demo Data'}
          </span>
        </div>
        <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-primary tracking-tight mt-2">
          {material.name}
        </h1>
        <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
          {material.material_form === 'flexible_film' ? 'Flexible film / pouch material' : 'Rigid container material'}
          {' · '}
          Cost tier {material.cost_level}/5
          {material.recyclable ? ' · Recyclable' : ''}
          {material.compostable ? ' · Compostable' : ''}
        </p>
      </div>

      <div className="rounded-xl bg-surface-container-lowest p-space-md shadow-sm flex flex-col gap-2">
        <span className="font-headline-sm text-headline-sm text-on-surface">Barrier & Performance Properties</span>
        {PROPS.map((p) => (
          <div key={p.key} className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-secondary">{p.icon}</span>
              <span className="font-body-sm text-body-sm text-on-surface">{p.label}</span>
            </div>
            <div className="flex items-center gap-0.5">
              {[1, 2, 3, 4, 5].map((i) => (
                <span
                  key={i}
                  className={`w-2.5 h-2.5 rounded-full ${
                    i <= material[p.key] ? 'bg-primary-container' : 'bg-surface-container-high'
                  }`}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-xl bg-surface-container-lowest p-space-md shadow-sm">
        <div className="flex items-center gap-1.5 mb-1">
          <span className="material-symbols-outlined text-[16px] text-secondary">place</span>
          <span className="font-headline-sm text-headline-sm text-on-surface">Example Applications</span>
        </div>
        <p className="font-body-sm text-body-sm text-on-surface-variant">{material.example_applications}</p>
      </div>

      <div className="rounded-xl bg-surface-container-lowest p-space-md shadow-sm">
        <span className="font-headline-sm text-headline-sm text-on-surface">Advantages</span>
        <ul className="flex flex-col gap-1.5 mt-2">
          {material.advantages.map((a, i) => (
            <li key={i} className="flex items-start gap-1.5 font-body-sm text-body-sm text-on-surface-variant">
              <span className="material-symbols-outlined text-[15px] text-primary flex-shrink-0 mt-0.5">check_circle</span>
              {a}
            </li>
          ))}
        </ul>
      </div>

      <div className="rounded-xl bg-surface-container-lowest p-space-md shadow-sm">
        <span className="font-headline-sm text-headline-sm text-on-surface">Limitations</span>
        <ul className="flex flex-col gap-1.5 mt-2">
          {material.limitations.map((l, i) => (
            <li key={i} className="flex items-start gap-1.5 font-body-sm text-body-sm text-on-surface-variant">
              <span className="material-symbols-outlined text-[15px] text-error flex-shrink-0 mt-0.5">cancel</span>
              {l}
            </li>
          ))}
        </ul>
      </div>

      <button
        onClick={() => toggleCompareSelection(material.id)}
        className={`w-full py-3 px-space-md rounded-xl font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md active:scale-[0.99] ${
          isSelected ? 'bg-secondary text-on-secondary' : 'bg-primary-container text-on-primary'
        }`}
      >
        <span className="material-symbols-outlined text-[20px]">
          {isSelected ? 'check_box' : 'add_circle'}
        </span>
        {isSelected ? 'Selected for Comparison' : 'Add to Comparison'}
      </button>
    </PageShell>
  )
}
