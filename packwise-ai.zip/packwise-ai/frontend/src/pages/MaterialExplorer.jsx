import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'
import { api } from '../api/client.js'

export default function MaterialExplorer() {
  const [materials, setMaterials] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [query, setQuery] = useState('')

  useEffect(() => {
    api
      .getMaterials()
      .then(setMaterials)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }, [])

  const filtered = materials.filter(
    (m) =>
      m.name.toLowerCase().includes(query.toLowerCase()) ||
      m.short_code.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <PageShell subtitle="Material Explorer">
      <div className="rounded-xl bg-surface-container-low p-space-md shadow-sm">
        <div className="flex items-center gap-1.5 text-secondary">
          <span className="material-symbols-outlined text-[18px]">inventory_2</span>
          <span className="font-label-caps text-label-caps uppercase tracking-wider font-semibold">
            Full Material Catalog
          </span>
        </div>
        <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-primary tracking-tight mt-1">
          Packaging Material Explorer
        </h1>
      </div>

      <div className="flex items-center gap-2 bg-surface-container-lowest rounded-lg px-3 py-2 shadow-sm">
        <span className="material-symbols-outlined text-secondary text-[20px]">search</span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search materials..."
          className="font-body-md text-body-md text-on-surface bg-transparent w-full focus:outline-none"
        />
      </div>

      {loading && <p className="font-body-sm text-on-surface-variant text-center py-4">Loading materials...</p>}
      {error && (
        <div className="rounded-lg bg-error-container p-space-sm text-on-error-container font-body-sm text-body-sm">
          {error}
        </div>
      )}

      <div className="flex flex-col gap-space-sm">
        {filtered.map((m) => (
          <Link
            key={m.id}
            to={`/materials/${m.id}`}
            className="flex items-center justify-between gap-2 rounded-xl bg-surface-container-lowest p-space-sm shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex flex-col min-w-0">
              <span className="font-body-md text-body-md font-semibold text-on-surface truncate">{m.name}</span>
              <span className="font-technical-data text-[10px] text-on-surface-variant">
                {m.short_code} · {m.material_form === 'flexible_film' ? 'Flexible Film' : 'Rigid Container'}
              </span>
              <span className="font-body-sm text-[11px] text-on-surface-variant mt-0.5 line-clamp-1">
                {m.example_applications}
              </span>
            </div>
            <span className="material-symbols-outlined text-[20px] text-on-surface-variant flex-shrink-0">
              chevron_right
            </span>
          </Link>
        ))}
      </div>
    </PageShell>
  )
}
