import React from 'react'
import { useNavigate, Link } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'
import { useAppContext } from '../context/AppContext.jsx'

const BARS = [
  { key: 'oxygen_barrier', label: 'Oxygen Barrier', icon: 'air' },
  { key: 'moisture_barrier', label: 'Moisture Barrier', icon: 'water_drop' },
  { key: 'light_barrier', label: 'Light Barrier', icon: 'wb_sunny' },
  { key: 'grease_resistance', label: 'Grease Resistance', icon: 'opacity' },
]

function scoreColor(score) {
  if (score >= 70) return 'text-primary'
  if (score >= 50) return 'text-secondary'
  return 'text-amber-700'
}

export default function Recommendations() {
  const navigate = useNavigate()
  const { recommendation, selectedForCompare, toggleCompareSelection } = useAppContext()

  if (!recommendation) {
    return (
      <PageShell subtitle="Recommendation Results">
        <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
          <span className="material-symbols-outlined text-[40px] text-on-surface-variant">verified</span>
          <p className="font-body-md text-body-md text-on-surface-variant">
            No recommendation yet. Enter food parameters to run the AI analysis.
          </p>
          <button
            onClick={() => navigate('/food-input')}
            className="mt-2 px-4 py-2.5 rounded-xl bg-primary-container text-on-primary font-body-md font-semibold"
          >
            Go to Food Input
          </button>
        </div>
      </PageShell>
    )
  }

  const { food_name, results } = recommendation

  return (
    <PageShell subtitle="Recommendation Results">
      <div className="relative overflow-hidden rounded-xl bg-surface-container-low p-space-md shadow-sm">
        <div className="flex items-center gap-1.5 text-secondary">
          <span className="material-symbols-outlined text-[18px]">verified</span>
          <span className="font-label-caps text-label-caps uppercase tracking-wider font-semibold">
            Top 3 AI-Ranked Materials
          </span>
        </div>
        <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-primary tracking-tight mt-1">
          {food_name}
        </h1>
        <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
          Ranked by explainable compatibility score. Select up to 3 to compare side-by-side.
        </p>
      </div>

      <div className="flex flex-col gap-space-sm">
        {results.map((r, idx) => {
          const isSelected = selectedForCompare.includes(r.material_id)
          return (
            <div
              key={r.material_id}
              className="flex flex-col rounded-xl bg-surface-container-lowest p-space-md shadow-sm gap-space-sm"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-primary-container/15 flex items-center justify-center text-primary font-bold font-technical-data text-[13px] flex-shrink-0">
                    #{idx + 1}
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="font-body-md text-body-md font-semibold text-on-surface truncate">
                      {r.material_name}
                    </span>
                    <span className="font-technical-data text-[10px] text-on-surface-variant">
                      {r.short_code} ·{' '}
                      {r.material_form === 'flexible_film' ? 'Flexible Film' : 'Rigid Container'} ·{' '}
                      {r.data_status === 'validated' ? 'Validated Data' : 'Prototype Data'}
                    </span>
                  </div>
                </div>
                <div className={`font-metric-display text-[22px] font-bold flex-shrink-0 ${scoreColor(r.compatibility_score)}`}>
                  {r.compatibility_score}
                  <span className="text-[12px] font-medium text-on-surface-variant">%</span>
                </div>
              </div>

              {/* Barrier property mini bars */}
              <div className="grid grid-cols-2 gap-2">
                {BARS.map((b) => (
                  <div key={b.key} className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-1 font-label-caps text-[9.5px] text-on-surface-variant">
                      <span className="material-symbols-outlined text-[12px]">{b.icon}</span>
                      {b.label}
                    </div>
                    <div className="w-full bg-surface-container-high h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-primary-container h-full rounded-full"
                        style={{ width: `${(r[b.key] / 5) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="rounded-lg bg-surface-container-low p-space-sm flex items-start gap-2">
                <span className="material-symbols-outlined text-[15px] text-secondary flex-shrink-0 mt-0.5">
                  lightbulb
                </span>
                <div className="flex flex-col gap-1">
                  {r.reasons.slice(0, 2).map((reason, i) => (
                    <p key={i} className="font-body-sm text-body-sm text-on-surface-variant">
                      {reason}
                    </p>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-1.5 px-1">
                <span className="material-symbols-outlined text-[14px] text-on-surface-variant">place</span>
                <span className="font-body-sm text-body-sm text-on-surface-variant">
                  Typically used for: {r.example_applications}
                </span>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => toggleCompareSelection(r.material_id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg font-label-caps text-[11px] font-semibold transition-colors ${
                    isSelected
                      ? 'bg-secondary text-on-secondary'
                      : 'bg-surface-container text-on-surface-variant hover:bg-surface-container-high'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">
                    {isSelected ? 'check_box' : 'check_box_outline_blank'}
                  </span>
                  {isSelected ? 'Selected for Compare' : 'Add to Compare'}
                </button>
                <Link
                  to={`/materials/${r.material_id}`}
                  className="flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-surface-container text-on-surface-variant hover:bg-surface-container-high font-label-caps text-[11px] font-semibold"
                >
                  Details
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </Link>
              </div>
            </div>
          )
        })}
      </div>

      <div className="flex flex-col gap-2 pt-1 pb-2">
        <button
          onClick={() => navigate('/comparison')}
          disabled={selectedForCompare.length < 2}
          className="w-full py-3 px-space-md rounded-xl bg-secondary text-on-secondary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md disabled:opacity-40 transition-all active:scale-[0.99]"
        >
          <span className="material-symbols-outlined text-[20px]">compare_arrows</span>
          Compare Selected ({selectedForCompare.length})
        </button>
        <button
          onClick={() => navigate('/report')}
          className="w-full py-3 px-space-md rounded-xl bg-surface-container-lowest border border-outline-variant/40 text-on-surface font-body-md font-semibold flex items-center justify-center gap-2"
        >
          <span className="material-symbols-outlined text-[18px]">description</span>
          Generate Full Report
        </button>
      </div>
    </PageShell>
  )
}
