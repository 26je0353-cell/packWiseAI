import React from 'react'
import { useNavigate } from 'react-router-dom'
import PageShell from '../components/PageShell.jsx'
import { useAppContext } from '../context/AppContext.jsx'

export default function Report() {
  const navigate = useNavigate()
  const { recommendation, foodParams } = useAppContext()

  if (!recommendation) {
    return (
      <PageShell subtitle="Recommendation Report">
        <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
          <span className="material-symbols-outlined text-[40px] text-on-surface-variant">description</span>
          <p className="font-body-md text-body-md text-on-surface-variant">
            Run an analysis first to generate a report.
          </p>
          <button
            onClick={() => navigate('/food-input')}
            className="mt-2 px-4 py-2.5 rounded-xl bg-primary-container text-on-primary font-body-md font-semibold"
          >
            Go to Food Input
          </button>
        </div>
      </PageShell>
    )
  }

  const { food_name, results, recommendation_id } = recommendation
  const today = new Date().toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })

  return (
    <PageShell subtitle="Recommendation Report">
      <div id="report-content" className="flex flex-col gap-space-md">
        <div className="rounded-xl bg-surface-container-low p-space-md shadow-sm">
          <div className="flex items-center gap-1.5 text-secondary">
            <span className="material-symbols-outlined text-[18px]">description</span>
            <span className="font-label-caps text-label-caps uppercase tracking-wider font-semibold">
              PackWise AI · Recommendation Report #{recommendation_id}
            </span>
          </div>
          <h1 className="font-headline-lg-mobile text-headline-lg-mobile text-primary tracking-tight mt-1">
            {food_name}
          </h1>
          <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">Generated {today}</p>
        </div>

        <div className="rounded-xl bg-surface-container-lowest p-space-md shadow-sm">
          <span className="font-headline-sm text-headline-sm text-on-surface">Input Parameters</span>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {[
              ['Category', foodParams.food_category],
              ['Moisture Sensitivity', `${foodParams.moisture_sensitivity}/5`],
              ['Oxygen Sensitivity', `${foodParams.oxygen_sensitivity}/5`],
              ['Light Sensitivity', `${foodParams.light_sensitivity}/5`],
              ['Fat Content', `${foodParams.fat_content}/5`],
              ['Storage Temp', `${foodParams.storage_temperature_c}°C`],
              ['Relative Humidity', `${foodParams.relative_humidity}% RH`],
              ['Target Shelf Life', `${Math.round(foodParams.expected_shelf_life_days / 30)} months`],
              ['Cost Priority', `${foodParams.cost_priority}/5`],
              ['Sustainability Priority', `${foodParams.sustainability_priority}/5`],
            ].map(([label, value]) => (
              <div key={label} className="rounded-lg bg-surface-container-low p-2">
                <div className="font-label-caps text-[9px] text-on-surface-variant uppercase">{label}</div>
                <div className="font-technical-data text-[12px] text-on-surface font-semibold">{value}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-space-sm">
          <span className="font-headline-sm text-headline-sm text-on-surface px-1">
            Ranked Recommendations
          </span>
          {results.map((r, idx) => (
            <div key={r.material_id} className="rounded-xl bg-surface-container-lowest p-space-md shadow-sm">
              <div className="flex items-center justify-between">
                <span className="font-body-md text-body-md font-bold text-on-surface">
                  #{idx + 1} {r.material_name}
                </span>
                <span className="font-metric-display text-[18px] font-bold text-primary">
                  {r.compatibility_score}%
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                {r.example_applications}
              </p>
              <div className="mt-2 flex flex-col gap-1">
                {r.reasons.map((reason, i) => (
                  <p key={i} className="font-body-sm text-[11.5px] text-on-surface-variant flex gap-1">
                    <span className="material-symbols-outlined text-[12px] text-secondary flex-shrink-0 mt-0.5">
                      arrow_right
                    </span>
                    {reason}
                  </p>
                ))}
              </div>
              <div className="mt-2 font-label-caps text-[9px] px-2 py-0.5 rounded-full inline-block bg-surface-container text-on-surface-variant">
                {r.data_status === 'validated' ? 'Validated Data' : 'Prototype/Demo Data'}
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-lg bg-secondary-container/20 p-space-sm flex items-start gap-2">
          <span className="material-symbols-outlined text-[18px] text-secondary flex-shrink-0 mt-0.5">
            info
          </span>
          <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
            This report is generated by a transparent, rule-based scoring model for prototype/demo
            purposes. It is not a substitute for lab-validated packaging compatibility testing.
          </p>
        </div>
      </div>

      <button
        onClick={() => window.print()}
        className="w-full py-3 px-space-md rounded-xl bg-primary-container text-on-primary font-headline-sm text-headline-sm flex items-center justify-center gap-2 shadow-md active:scale-[0.99]"
      >
        <span className="material-symbols-outlined text-[20px]">print</span>
        Print / Save as PDF
      </button>
    </PageShell>
  )
}
